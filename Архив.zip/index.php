<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  </head>
  <body>
    <h1>Тестируем PHP</h2>
      <ul style="list-style: none;">
        <li>Урок 1</li>
        <li><a href="lessons/lesson2.php">Урок 2</a></li>
        <li><a href="lessons/lesson3.php">Урок 3</a></li>
        <li><a href="lessons/lesson4/lesson4.php">Урок 4</a></li>
        <li><a href="lessons/lesson5/index.php">Урок 5</a></li>
        <li><a href="lessons/lesson_css.php">css</a></li>
      </ul>
  </body>
</html>
